# CHANGELOG

## [v1.0.0] - YYYY-MM-DD
- Inicialización del proyecto
